# Task: קניין רוחני — lessons [1, 2, 3]
Read /home/claude/packs/SPEC.md carefully and follow it exactly. For format see a finished lesson module, e.g. /home/claude/evpack/l4.py or any lN.py in /home/claude/packs/intro/ that passes check.py.

Course: קניין רוחני (course id `ip`, directory /home/claude/packs/ip/). The full 15-lesson syllabus (fixed order) is:
1. מבוא לקניין רוחני
2. זכות יוצרים — היקף ההגנה
3. יצירות מוגנות וזכות מוסרית
4. שימוש הוגן
5. פטנטים — חדשנות והתקדמות המצאתית
6. סימני מסחר
7. מוניטין וגניבת עין
8. מדגמים ועיצובים
9. סודות מסחריים
10. הגנה על תוכנה
11. רישוי והעברת זכויות
12. אכיפה וסעדים
13. קניין רוחני ובינה מלאכותית
14. שמות מתחם
15. היבטים בינלאומיים

Write these lessons as full in-depth modules: l1.py — N=1 — "מבוא לקניין רוחני", l2.py — N=2 — "זכות יוצרים — היקף ההגנה", l3.py — N=3 — "יצירות מוגנות וזכות מוסרית".
Look at the neighbouring lessons' titles so you don't overlap them; cover your topic completely for this course
(Israeli law, LLB course + bar-exam level). Statute texts available in the app: /home/claude/packs/statutes/*.txt.
Do the research per SPEC (several sources per lesson, verify every case citation), write originally in Hebrew,
validate each file with `python3 /home/claude/packs/check.py /home/claude/packs/ip lN` until OK.
Return the short final report described in SPEC.
